package sample;


import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;
import java.util.List;

public class Controller {

    private ArrayList<Character> CharQ; // list of all characters on Scene
    int iterate; //to go through CharQ

    private Skill activeSkill;
    @FXML
    private Label viewLog;
    @FXML
    private GridPane stage;
    @FXML
    private Button skillOne;
    @FXML
    private Button skillTwo;
    @FXML
    private Button skillThree;
    @FXML
    private Button skillFour;
    @FXML
    private Button skillFive;
    @FXML
    private Button skillSix;
    @FXML
    private Label curInfo;
    @FXML
    private Label int0;
    @FXML
    private Label int1;
    @FXML
    private Label int2;
    @FXML
    private Label int3;
    @FXML
    private Label int4;
    @FXML
    private Label int5;
    @FXML
    private Label int6;






    private ArrayList<Button> buttonSkillList; // to ease access to skill buttons on bottom menu
    private ArrayList<Label> iniative=new ArrayList<Label>();

    Character pointer;
    Character target; // for attacking a creature
    Character CharacterDeatils; // For displaying info




    public void initialized(ArrayList<Character> e){
        buttonSkillList = new ArrayList<Button>();
        buttonSkillList.add(0, skillOne);
        buttonSkillList.add(1 , skillTwo);
        buttonSkillList.add(2, skillThree);
        buttonSkillList.add(3 , skillFour);
        buttonSkillList.add(4 , skillFive );
        buttonSkillList.add(5 , skillSix );
        prepareInitative();
        iterate=0;
        CharQ=e;
            for(int n=0; n<6;n++){
                buttonSkillList.get(n).setDisable(true); // For starters turn off non usable buttons. When loading new Character set some of them to enabled
            }
        setPoint(CharQ.get(0));
            LoadSkills();
    } // seems to work
        //This should be the correct order of loading - first load character from list. Then enable buttons, according to how many skills a character has
    // setPoint used only in the begginig?
    public void setPoint(Character gob){
        pointer=gob;
        activeSkill = pointer.Equipment.get(0); // set active skill to the first of one from equpiment of current Character. May be later changed through either ChangeActiveSkill.
        // Overall should be changed both pointer and active whenever loading new character from initative order
        pointer.getcharImage().setStyle("-fx-border-color: green; -fx-border-width: 3; "+ pointer.getURL());


    }
    public void LoadSkills(){
        for(int n=0; n<pointer.Equipment.size();n++){
            buttonSkillList.get(n).setStyle(pointer.Equipment.get(n).getSource());
            buttonSkillList.get(n).setDisable(false);
          //  buttonSkillList.get(n).setStyle(pointer.Equipment.get(n).source); // This should load into button the same image that is in skill. Underline Should . Okay it works but here is blank image. Must rename jpg files with skills
        }
    }

    @FXML
    public void prepareInitative(){
        iniative.add(0, int0);
        iniative.add(1,int1);
        iniative.add(2,int2);
        iniative.add(3, int3);
        iniative.add(4, int4);
        iniative.add(5, int5);
        iniative.add(6,int6);
    }
    public  void updateIniative(int m){
        int n=m;
        for(int i=0;i<iniative.size();i++){
            iniative.get(i).setStyle(CharQ.get(n%CharQ.size()).getURL2());
            n++;
        }

    }

    @FXML
    public void ChangeActiveSkill(){
        if(skillOne.isPressed()){
            activeSkill=pointer.Equipment.get(0);
        }
        if(skillTwo.isPressed()){
            activeSkill=pointer.Equipment.get(1);
        }
        if(skillThree.isPressed()){
            activeSkill=pointer.Equipment.get(2);
        }
        if(skillFour.isPressed()){
            activeSkill=pointer.Equipment.get(3);
        }
        if(skillFive.isPressed()){
            activeSkill=pointer.Equipment.get(4);
        }
        if(skillSix.isPressed()){
            activeSkill=pointer.Equipment.get(5);
        }
    }
    //Unnecessary Long but otherwise doesnt work -Corecctly show Skill info
    @FXML
    public void ShowSkillInfo1(){
        if(!buttonSkillList.get(0).isDisabled()){
            viewLog.setText(pointer.Equipment.get(0).DisplayInfo());
        }
    }
    @FXML
    public void ShowSkillInfo2(){
        if(!buttonSkillList.get(1).isDisabled()){
            viewLog.setText(pointer.Equipment.get(1).DisplayInfo());
        }
    }
    @FXML
    public void ShowSkillInfo3(){
        if(!buttonSkillList.get(2).isDisabled()){
            viewLog.setText(pointer.Equipment.get(2).DisplayInfo());
        }
    }
    @FXML
    public void ShowSkillInfo4(){
        if(!buttonSkillList.get(3).isDisabled()){
            viewLog.setText(pointer.Equipment.get(3).DisplayInfo());
        }
    }
    @FXML
    public void ShowSkillInfo5(){
        if(!buttonSkillList.get(4).isDisabled()){
            viewLog.setText(pointer.Equipment.get(4).DisplayInfo());
        }
    }
    @FXML
    public void ShowSkillInfo6(){
        if(!buttonSkillList.get(5).isDisabled()){
            viewLog.setText(pointer.Equipment.get(5).DisplayInfo());
        }
    }





    @FXML
    public void HandleMouseEnter(){
        viewLog.setText("Im a viewLog");
    }

    public void DisplayCharacter( ArrayList<Character> loadOrder){
            for(int n=0;n< loadOrder.size();n++) {
                stage.add(loadOrder.get(n).getcharImage(), 1, 1);
                loadOrder.get(n).getcharImage().setTranslateY(loadOrder.get(n).getposY()*40);
                loadOrder.get(n).getcharImage().setTranslateX(loadOrder.get(n).getposX()*40);
            }

    }
    public void LoadCharacter(ArrayList<Character> example){
        CharQ=example;
    }


    public void ShowCordinates(MouseEvent event){ // shows coordinates and info on other characters

        int mouseX= (int) event.getX()/40;
        int mouseY= (int) event.getY()/40;
        boolean isOccupied = false; // Is square you clicked on occupoied - if yes go to attack. if not move there. Check if its in range!!
        for(int i=0; i<CharQ.size();i++){
            if((CharQ.get(i).getposY()==mouseY)&&(CharQ.get(i).getposX()==mouseX)){ // iterate throug list, avoiding yourself
                isOccupied=true;
                CharacterDeatils = CharQ.get(i);
            }

        }
        if(isOccupied){
            CharacterDeatils.DisplayInfo(viewLog);
            pointer.DisplayInfo(curInfo);

        }
        else {
            String Cord = "\tx=" + event.getX() + "\n \ty=" + event.getY() + "\n \t" + "Action=" + pointer.getcounter();
            viewLog.setText(Cord);
            pointer.DisplayInfo(curInfo);
        }
    }




    @FXML
    public void TakeAction(MouseEvent event){
        /* When Action is declared by clicking on the map two things can happen
        1. No enemies on square clicked - if ing range of movement , move there.
        2. If square is occupied you do attack
        Action ecenomy is taken care in Character class both in move and attack method
        TODO implement action ecenomy DONEEE!!!
        */  int mouseX= (int)(event.getX()/40);
            int mouseY= (int)(event.getY()/40);

        int mX= (int)event.getX()/40 - pointer.getposX() ;
        int mY= (int)event.getY()/40 - pointer.getposY();  //variables for moving

       // Character target = new Character(0,0, "NULL"); // pointer to actor on occupied square
      //  target.charImage.setVisible(false);

            int CharIndex= CharQ.indexOf(pointer); // to avoid attacking yourself
            int m = CharIndex+1;

            boolean isOccupied = false; // Is square you clicked on occupoied - if yes go to attack. if not move there. Check if its in range!!
        for(int i=0; i<CharQ.size()-1;i++){
            if((CharQ.get(m%CharQ.size()).getposY()==mouseY)&&(CharQ.get(m%CharQ.size()).getposX()==mouseX)){ // iterate throug list, avoiding yourself
                isOccupied=true;
                target = CharQ.get(m%CharQ.size());
            }
            m++;
        }
        if(isOccupied){ // attack
            if(((mX*mX+mY*mY)<=(activeSkill.getRange())*(activeSkill.getRange()))) { // see if you have range
                if(pointer.attack(target, activeSkill, viewLog)){
                    CharQ.remove(CharQ.indexOf(target)); // Remove target from list
                    target.getcharImage().setStyle("-fx-background-image: url('dead.png')");

                };



            }
            else{ viewLog.setText("CANT ATTACK _ OUT OF RANGE");
            }

        }
        else{
            if(((mX*mX+mY*mY)<=36)&& pointer.getmove()>0 &&pointer.getcounter()>0) { // see if you can move there ie if distance is less then move of Character.

                    pointer.getcharImage().setTranslateY(mouseY * 40);
                    pointer.getcharImage().setTranslateX(mouseX * 40);
                    pointer.move(mX, mY, viewLog);
                }

            else{ viewLog.setText("CANT MOVE");
            }

        }

    } // okay it Works!

    @FXML
    public void NextTurn(){
        // list skiping ie temp character =list remove
        // list add character termp. Or just go along with iterator
        // set counter in pointer.counter=2 then change pointer to next character in QUEUE
        pointer.resetCounter();
        iterate=iterate+1;
        pointer.getcharImage().setStyle(pointer.getURL());

        for(int i=0; i<6;i++){
            buttonSkillList.get(i).setDisable(true);
            buttonSkillList.get(i).setStyle("-fx-background-image: url('button_skill.jpg')");
        }
        setPoint(CharQ.get(iterate%CharQ.size()));
        updateIniative(CharQ.indexOf(pointer));


        LoadSkills();

    }


}
