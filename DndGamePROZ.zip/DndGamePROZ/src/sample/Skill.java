package sample;

import javafx.scene.control.Label;

import java.util.concurrent.ThreadLocalRandom;

public class Skill {
    private int damage;
    private Label objImage;
    private int price;
    private String type;
    private int rand;
    private String source;
    private int rarity;
    private int range;

    public  Skill(int rare){

        rarity= rare;
        damage= rare*3 +rare*ThreadLocalRandom.current().nextInt(1, 8 );
        price = rare*1000 + ThreadLocalRandom.current().nextInt(1, 100)*rare;
        type = "Skill";
        range= 5*ThreadLocalRandom.current().nextInt(1, 12);
        rand= ThreadLocalRandom.current().nextInt(1, 14 );
        source = "-fx-background-image: url('"+rand+".png')"; // whole command to set image
        objImage=new Label();
        objImage.setPrefHeight(50);
        objImage.setPrefWidth(50);
        objImage.setStyle(source);

    }

    public String DisplayInfo(){
        return  "\t"+"TYPE: " + type +"\n" +"\t"+ "DAMAGE: " + damage + "\n" +"\t"+ "RARITY: " + rarity + "\n" + "\t" +"RANGE: " + range;
    };

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public Label getObjImage() {
        return objImage;
    }

    public void setObjImage(Label objImage) {
        this.objImage = objImage;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getRand() {
        return rand;
    }

    public void setRand(int rand) {
        this.rand = rand;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getRarity() {
        return rarity;
    }

    public void setRarity(int rarity) {
        this.rarity = rarity;
    }

    public int getRange() {
        return range;
    }

    public void setRange(int range) {
        this.range = range;
    }
}
