package sample;

import javafx.scene.control.Label;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Character {

    private  String name;
    private Label charImage;
    private   String URL;
    private  String URL2;

    private  int counter; // counter to how many times one can do various actions in turn. default 2
    private int AC;
    private  int hp;
    private   int move;
    private int str;
    private  int wis;
    private int dex;
    private  int exp;

    private  int con; //four characteristics - str for melee damage, wis for magic , dex for ranged and con asa pseudo health thing TODO implement saves
    private    int level; // starting at 1. determines HP and primary stat
    private   int posX;
    private  int posY; // Used as a way to control where each actor is
    String type; // either creature or Object. Maybe change to boolean? might be easier
    ArrayList<Skill> Equipment = new ArrayList<Skill>();

    public Character(int x, int y, String url, int lvl, String nam , boolean on) {

        URL = "-fx-background-image: url('"+url+".png')";
        name = nam;
        level = lvl;
        counter = 2;
        move = 6;
        if(on) {
            charImage = new Label();
            charImage.setPrefWidth(40);
            charImage.setPrefHeight(40);
            charImage.setStyle(URL);
        }
        URL2 = "-fx-background-image: url('"+url+"BIG.png')";
        con = ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4);
        str = ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4);
        dex = ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4);
        wis = ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4) + ThreadLocalRandom.current().nextInt(1, 4);
        hp = 8 + (level - 1) * ThreadLocalRandom.current().nextInt(1, 6) + level * con / 3;
        AC = 10 + dex / 3 +level;
        posX = x;
        posY = y;
        exp=0;
        if(on) {
            Equipment.add(new Skill(level));
        }
        type = "Creature";
    }



    public void takeDamage(int damage) {
        hp = hp - damage;
    }



    public boolean attack(Character target, Skill action, Label log) {  //Again - print to label Succesful hit vs char.name!! It takes X points of damage
        // return 0 if target was not killed or 1 if it was. Easier then trying to remove him through object-> controller
        if (counter > 0) {
            int toHit;
            toHit = ThreadLocalRandom.current().nextInt(1, 20) + str / 3 + action.getRarity();
            if (toHit >= target.getAC()) {
                target.takeDamage(action.getDamage());
            } else {
                counter--;
                log.setText("To hit: "+ toHit+ "vs AC of: "+target.getAC() +"\n"+ "target missed!!");
                return false;
            }
            counter--;

            if(action.getDamage()>target.getHp()){
                log.setText("To hit: "+toHit + "vs AC of: "+target.getAC() +"\n"+ "Target was slain!!");
                exp = exp+target.getlevel();

                if(exp>=3){
                    level=level+1;
                    hp=8 + (level - 1) * ThreadLocalRandom.current().nextInt(1, 6) + level * con / 3;
                    exp=exp-3;
                    AC=10 + dex / 3 +level;
                    if(Equipment.size()<6){
                        Equipment.add(new Skill(level+1));
                    }
                }
                return true;
            }
            else{
                log.setText("To hit: "+toHit + "vs AC of: "+target.getAC() +"\n"+ "Target was succesfully hit!");
                return false;
            }

        }
        log.setText("Not enough actions - end your turn!");
        return false;
    }

    public boolean attack_test(Character target, int damage) {  //Again - print to label Succesful hit vs char.name!! It takes X points of damage
        // return 0 if target was not killed or 1 if it was. Easier then trying to remove him through object-> controller
        if (counter > 0) {
            int toHit;
            toHit = ThreadLocalRandom.current().nextInt(1, 20) + str / 3 ;
            if (toHit >= target.getAC()) {
                target.takeDamage(damage);
            } else {
                counter--;
                return false;
            }
            counter--;

            if(damage>target.getHp()){

                exp = exp+target.getlevel();

                if(exp>=3){
                    level=level+1;
                    hp=8 + (level - 1) * ThreadLocalRandom.current().nextInt(1, 6) + level * con / 3;
                    exp=exp-3;
                    AC=10 + dex / 3 +level;
                    if(Equipment.size()<6){
                        Equipment.add(new Skill(level+1));
                    }
                }
                return true;
            }
            else{

                return false;
            }

        }

        return false;
    }



    public void move(int x, int y, Label log) {  //Use to return information about action to event log in game!
        if (counter > 0) {
            if ((x * x + y * y) <= 36) {
                posX = posX + x;
                posY = posY + y;
                counter--;
                log.setText("Character moved");
            } else {
                log.setText("failed to move");
            }
        } else {
            log.setText("Not enogh actions - end turn!");
        }


    }

    public void move_test(int x, int y) {  //Method specifically for tests beacuse they dont mesh well with javafx elements like Labels etc
        if (counter > 0) {
            if ((x * x + y * y) <= 36) {
                posX = posX + x;
                posY = posY + y;
                counter--;

            }


        }
    }


    public int getAC(){
        return AC;
    };
    public void setAC(int n){
       AC=n;
    };
    public void resetCounter(){
        counter = 2;
    };
    public void setCounter(int n){
        counter=n;
    }
    public void DisplayInfo(Label log){
        String s;
        String b;
        b="\n\tSTR "+ str+"\n\tDEX "+ dex +"\n\tCON "+ con + "\n\tWIS "+ wis;
        s= "\tTYPE: "+ type +"\n\tNAME: " + name+ "\n\tHP: " + hp  +"\n\tAC:"+AC +"\n\tLEVEL: "+ level ;
        s=s+b;
        log.setText(s);
    }
    public int getHp(){
        return hp;
    }
    public void setHp(int n){
        hp=n;
    }
    public int getlevel(){
        return  level;
    }
    public int getposX(){
        return posX;
    }
    public int getposY(){
        return posY;
    }
    public Label getcharImage(){
        return  charImage;
    }
    public int getcounter(){
        return counter;
    }
    public int getmove(){
        return move;
    }
    public String getURL(){
        return URL;
    }
    public String getURL2(){
        return  URL2;
    }

}

