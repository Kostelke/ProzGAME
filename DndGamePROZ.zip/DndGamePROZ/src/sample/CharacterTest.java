package sample;

import org.junit.Test;

import static org.junit.Assert.*;


// Tests are carried out on test versions of methods because test interact poorly with java fx. Dude to this only Character has unit test and even then not many of them
// This is due to the fact that there are only three main operation to be carried out - move, attack and take damage
// Beacuse of this method attack has been changed to not included reference to equipment array - aas such its flat damage value which we can check


public class CharacterTest {
    private Character test;
    private Character test2;
    private Character test_attack;
    private Character test_attack2;
    private Character test_target0;
    private Character test_target1;
    private Character test_target2;
    private Character test_target3;

    private int a;


    @Test
    public void takeDamage() {
        //given
        test=new Character(1,1,"goblin", 29,"Sułtan kosmitów", false);
        a=test.getHp();

        //when
        test.takeDamage(5);

        //then
        assertTrue(a==(test.getHp()+5));

    }

    @Test
    public void attack() {
        //given
    test_target0= new Character(0,0,"goblin",0, "ZERO_HP", false);          /// test if kills
    test_target1= new Character(0,0,"goblin",1, "HUGE_HP", false);        // test if damages and see if correctly
    test_target2= new Character(0,0,"goblin",1, "ZERO_HP", false);          // test when no actions
    test_target3= new Character(0,0,"goblin",2, "ZERO_HP", false);          //test when missed

    test_attack= new Character(0,0,"goblin",5,"ddd", false) ;
    test_attack2= new Character(0,0,"goblin",5,"ddd", false);

        test_target0.setHp(1);
        test_target1.setAC(0);
        test_attack2.setCounter(0);
        test_target3.setAC(60);
        a=test_target1.getHp();

       //when
        test_attack.attack_test(test_target1, 1);

        //then
        assertTrue(test_attack.attack_test(test_target0,5));
        assertTrue(a==(test_target1.getHp()+1));
        assertTrue(test_attack2.attack_test(test_target2,5));
        assertTrue(test_attack.attack_test(test_target3,5));


    }

    @Test
    public void move() {
        //given
        test2 = new Character(0,0,"goblin", 2, "Zorro", false);

        //when
        test2.move_test(1, 1);

        // then

        assertTrue(test2.getposX()==1);
        assertTrue(test2.getposY()==1);
    }


}