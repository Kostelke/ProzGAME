package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{


        FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
        Parent root = loader.load();

        Controller myController = loader.getController();

        primaryStage.setTitle("Dungeon Explorer");
        primaryStage.setScene(new Scene(root, 1400, 1040));
        primaryStage.setResizable(false);
        primaryStage.show();
        ArrayList<Character> chartable = new ArrayList<Character>();
        for(int i=0; i<5; i++){
            chartable.add(new Character(12, i+6, "goblin", 1, "Goblin Raider",true ));
        }
        chartable.add(new Character(18 , 10, "demon", 3, "Demon Warrior",true ));
        chartable.add(new Character(18 , 15, "beholder", 10, "Beholder Driizzt",true ));
        chartable.add(new Character(2, 8, "knight", 3, "Sir Iam Mckellen" ,true));
        chartable.add(new Character(2, 12, "mage", 3, "Papito the foul" ,true));
        chartable.get(6).Equipment.add(new Skill(5));
        chartable.get(5).Equipment.add(new Skill(5));

        myController.initialized(chartable);
        myController.updateIniative(0);

        myController.LoadSkills();
      myController.DisplayCharacter(chartable);


    }


    public static void main(String[] args) {
        launch(args);
    }
}
