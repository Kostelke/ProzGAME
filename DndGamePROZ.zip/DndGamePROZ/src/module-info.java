module DndGamePROZ {
    requires javafx.fxml;
    requires javafx.controls;
    requires junit;
    opens sample;
}